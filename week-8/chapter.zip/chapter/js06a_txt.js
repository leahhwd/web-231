"use strict";
/*    JavaScript 7th Edition
      Chapter 6
      Chapter case

      Order Form Code
      Author: Leah Harris
      Date:   02/29/2024

      Filename: js06a.js
 */



