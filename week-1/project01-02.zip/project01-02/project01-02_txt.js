/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Leah Harris
    Date:  01-10-24

    Filename: project01-02.js
*/

//define variables for service name and service speed
