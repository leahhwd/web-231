/*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: Leah Harris
      Date: 01-20-24

      Filename: project02-02.js
 */

